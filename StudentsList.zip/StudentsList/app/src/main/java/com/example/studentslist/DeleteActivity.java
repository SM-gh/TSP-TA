package com.example.studentslist;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class DeleteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.acivity_delete);

        final EditText edtSchoolarIdDelete;
        Button btnAcept;

        edtSchoolarIdDelete = (EditText) findViewById(R.id.edtSchoolarIdDelete);
        btnAcept = (Button) findViewById(R.id.btnAcept);

        btnAcept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final SQLiteDb sqLiteDb = new SQLiteDb(getApplicationContext());
                sqLiteDb.DeleteStudents(edtSchoolarIdDelete.getText().toString().trim());
                Toast.makeText(getApplicationContext(),R.string.msgSuccessfulDelete,Toast.LENGTH_SHORT).show();
                Intent back = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(back);
            }
        });
    }
}
