package com.example.studentslist;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class SQLiteDb extends SQLiteOpenHelper {

    //private static final String TABLE_STUDENTS="CREATE TABLE STUDENTS(NAMES TEXT, LASTNAMES TEXT, ID TEXT, IMAGE IMAGEVIEW)";

    private static final String TABLE_STUDENTS="CREATE TABLE STUDENTS(ID TEXT PRIMARY KEY, NAMES TEXT, LASTNAMES TEXT, IMAGE IMAGEVIEW)";

    public SQLiteDb(Context context) {
        super(context, "db_students", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(TABLE_STUDENTS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS TABLE_STUDENTS");
        onCreate(sqLiteDatabase);
    }

    /*public void AddStudents(String names, String lastnames , String id, int img){
        SQLiteDatabase bd = getWritableDatabase();
        if(bd != null){
            bd.execSQL("INSERT INTO STUDENTS VALUES('"+names+"','"+lastnames+"','"+id+"','"+img+"')");
            bd.close();
        }
    }*/

    public void AddStudents(String id, String names , String lastnames, int img){
        SQLiteDatabase bd = getWritableDatabase();
        if(bd != null){
            bd.execSQL("INSERT INTO STUDENTS VALUES('"+id+"','"+names+"','"+lastnames+"','"+img+"')");
            bd.close();
        }
    }

    public List<Student> ShowStudents(){
        SQLiteDatabase bd = getReadableDatabase();
        final Cursor cursor = bd.rawQuery("SELECT * FROM STUDENTS",null);
        final List<Student> students = new ArrayList<>();
        if(cursor.moveToFirst()){
            do{
                students.add(new Student(cursor.getString(0),cursor.getString(1),cursor.getString(2), cursor.getInt(3)));
            }while (cursor.moveToNext());
        }
        return students;
    }

    /*public void EditStudentsList(String names, String lastnames , String id, int img){
        SQLiteDatabase bd = getWritableDatabase();
        if(bd != null){
            bd.execSQL("UPDATE STUDENTS SET ID='"+id+"', NAMES='"+names+"', LASTNAMES='"+lastnames+"',IMAGE='"+img+"'");
            bd.close();
        }
    }*/

    public void DeleteStudents( String id){
        SQLiteDatabase bd = getWritableDatabase();
        if(bd != null){
            bd.execSQL("DELETE FROM STUDENTS WHERE ID='"+id+"'");
            bd.close();
        }
    }
}
