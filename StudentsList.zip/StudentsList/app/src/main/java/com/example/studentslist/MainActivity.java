package com.example.studentslist;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edtNames, edtLastNames, edtSchoolarId;
    Button btnRegister, btnShow;
    RadioButton rdbtnMale, rdbtnFemale;
    RadioGroup rdgGender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_main);

        edtNames = (EditText) findViewById(R.id.edtNames);
        edtLastNames = (EditText) findViewById(R.id.edtLastNames);
        edtSchoolarId = (EditText) findViewById(R.id.edtSchoolarId);
        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnShow = (Button) findViewById(R.id.btnShow);
        rdbtnMale = (RadioButton) findViewById(R.id.rdbtnMale);
        rdbtnFemale = (RadioButton) findViewById(R.id.rdbtnFemale);
        rdgGender = (RadioGroup) findViewById(R.id.rdgGender);


        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ValidateFields();
            }
        });

        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent DeployStudents = new Intent(getApplicationContext(), StudentsActivity.class);
                startActivity(DeployStudents);
            }
        });

        /*btnDelete.setOnClickListener(new View.OnClickListener() {
            final SQLiteDb sqLiteDb = new SQLiteDb(getApplicationContext());
            @Override
            public void onClick(View v) {
                sqLiteDb.DeleteStudents(edtSchoolarId.getText().toString().trim());
                Toast.makeText(getApplicationContext(),"Se modificó",Toast.LENGTH_SHORT).show();;
            }
        });*/
    }

    private void ValidateFields(){

        String StringNames = edtNames.getText().toString().trim();
        String StringLastNames = edtLastNames.getText().toString().trim();
        String StringSchoolarId = edtSchoolarId.getText().toString().trim();

        final SQLiteDb sqLiteDb = new SQLiteDb(getApplicationContext());

        if(StringNames.isEmpty()){
            edtNames.setError(getString(R.string.alert_EmptyField));
            edtNames.requestFocus();
        } else if(StringLastNames.isEmpty()){
            edtLastNames.setError(getString(R.string.alert_EmptyField));
            edtLastNames.requestFocus();
        } else if(StringSchoolarId.isEmpty()){
            edtSchoolarId.setError(getString(R.string.alert_EmptyField));
            edtSchoolarId.requestFocus();
        }else if(rdgGender.getCheckedRadioButtonId()==-1){
            Toast.makeText(getApplicationContext(), R.string.alert_EmptyGender, Toast.LENGTH_SHORT).show();
        }else{
            if (rdbtnMale.isChecked()){
                sqLiteDb.AddStudents(StringSchoolarId, StringNames, StringLastNames,R.drawable.man);
                CleanFields();
            }else if(rdbtnFemale.isChecked()){
                sqLiteDb.AddStudents(StringSchoolarId, StringNames, StringLastNames,R.drawable.woman);
                CleanFields();
            }
            Toast.makeText(getApplicationContext(), R.string.msgSuccessfulRegister, Toast.LENGTH_SHORT).show();
        }
    }

    private void CleanFields(){
        edtNames.setText("");
        edtLastNames.setText("");
        edtSchoolarId.setText("");
        rdgGender.clearCheck();
    }
}
