package com.example.studentslist;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import java.util.List;

public class AdapterStudentsList extends RecyclerView.Adapter<AdapterStudentsList.ViewHolder>
        implements View.OnClickListener {

    public static class ViewHolder extends RecyclerView.ViewHolder{

        private TextView CompleteName;
        ImageView ImageStudent;

        public ViewHolder(View itemView){
            super(itemView);
            CompleteName = (TextView) itemView.findViewById(R.id.tvCompleteName);
            ImageStudent = (ImageView) itemView.findViewById(R.id.imgStudent);
        }
    }

    public List<Student>studentsList;

    public AdapterStudentsList(List<Student>studentsList){
        this.studentsList = studentsList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_student,parent,false);
        ViewHolder  viewHolder= new ViewHolder(view);
        view.setOnClickListener(this);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder (ViewHolder holder, final int position) {
        holder.CompleteName.setText(studentsList.get(position).getNames() + " " + studentsList.get(position).getLastNames());
        holder.ImageStudent.setImageResource(studentsList.get(position).getImage());
    }

    @Override
    public int getItemCount() {
        return studentsList.size();
    }

    private View.OnClickListener listener;

    public void setOnClickListener(View.OnClickListener listener){
        this.listener=listener;
    }

    @Override
    public void onClick(View view) {
        if(listener!=null) {
            listener.onClick(view);
        }
    }
}
