package com.example.studentslist;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class StudentsActivity extends AppCompatActivity {

    private RecyclerView recyclerViewStudents;
    private AdapterStudentsList adapterStudentsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_students_list);

        recyclerViewStudents= (RecyclerView) findViewById(R.id.recyclerStudents);
        recyclerViewStudents.setLayoutManager(new LinearLayoutManager(this));

        final SQLiteDb sqLiteDb = new SQLiteDb(getApplicationContext());
        recyclerViewStudents.setAdapter(adapterStudentsList);

        adapterStudentsList = new AdapterStudentsList(sqLiteDb.ShowStudents());
        adapterStudentsList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Id: "+adapterStudentsList.studentsList.get(recyclerViewStudents.getChildAdapterPosition(view)).getId(),Toast.LENGTH_SHORT).show();
            }
        });
        recyclerViewStudents.setAdapter(adapterStudentsList);

        Button btnDelete = (Button) findViewById(R.id.btnDelete);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent deleteStudent = new Intent(getApplicationContext(),DeleteActivity.class);
                startActivity(deleteStudent);
            }
        });
    }

}
