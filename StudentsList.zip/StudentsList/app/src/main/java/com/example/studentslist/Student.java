package com.example.studentslist;

public class Student {

    private String Names, LastNames, Id;
    private  int Image;

    public Student(String id, String names, String lastNames, int image) {
        Names = names;
        LastNames = lastNames;
        Id = id;
        Image = image;
    }

    public Student(){}

    public String getNames() {
        return Names;
    }

    public void setNames(String names) {
        Names = names;
    }

    public String getLastNames() {
        return LastNames;
    }

    public void setLastNames(String lastNames) {
        LastNames = lastNames;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public int getImage() {
        return Image;
    }

    public void setImage(int image) {
        Image = image;
    }
}
