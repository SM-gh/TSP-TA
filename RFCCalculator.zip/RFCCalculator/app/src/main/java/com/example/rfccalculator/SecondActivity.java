package com.example.rfccalculator;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Normalizer;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SecondActivity extends Activity {

    TextView tv_Age, tv_RFC, tv_ZodiacSign;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Bundle BundleSecond = getIntent().getExtras();
        int dBd = BundleSecond.getInt("DayBirthdate");
        int mBd = BundleSecond.getInt("MonthBirthdate");
        int yBd = BundleSecond.getInt("YearBirthdate");
        String namesRFC = BundleSecond.getString("stringnames");
        String lastnameRFC = BundleSecond.getString("stringlastname");
        String motherslastnameRFC = BundleSecond.getString("stringmotherslastname");

        CalculateRFC(namesRFC, lastnameRFC, motherslastnameRFC, dBd, mBd, yBd);
        CalculateAge(dBd, mBd, yBd);
        CalculateZodiacSign(dBd, mBd);
    }

    private void CalculateRFC(String Names, String LastName, String MothersLastName, int dNc, int mNc, int aNc)
    {
        Names = StringNormalizer(Names);
        LastName = StringNormalizer(LastName);
        MothersLastName = StringNormalizer(MothersLastName);

        Pattern pattern = Pattern.compile("\\A(?:(?:MARIA|JOSE) )?+(?:(?:DEL?|L(?:AS?|OS)|M(?:AC|[CI])|V[AO]N|Y)\\b ?)*+([A-Z&]?)([A-Z&]?)");
        final Matcher matcherNames = pattern.matcher(Names);
        matcherNames.find();

        pattern = Pattern.compile("\\A(?:(?:DEL?|L(?:A|AS?|OS|E|ES)|D(?:[AID]|AS|ER|IE)|M(?:AC|[CI])|V[AO]N|Y)\\b ?)*+(([A-Z&]?)[B-DF-HJ-NP-TV-Z&]*([AEIOU]?)[A-Z&]?)");
        final Matcher matcherLastName = pattern.matcher(LastName);
        matcherLastName.find();

        final Matcher matcherMothersLastName = pattern.matcher(MothersLastName);
        matcherMothersLastName.find();

        String letterNames = matcherNames.group(1);
        String letterLastName = matcherLastName.group(2);
        String letterMothersLastName = matcherMothersLastName.group(2);
        String rfcString, RFC;

        if (letterLastName.isEmpty() || letterMothersLastName.isEmpty()) {
            rfcString = (matcherLastName.group(1) + matcherMothersLastName.group(1)).substring(0,2) + letterNames + matcherNames.group(2);
        }
        else if (matcherLastName.group(1).length() > 2)
        {
            String vocal = matcherLastName.group(3);
            if (vocal.isEmpty())
                vocal = "X";
            rfcString = letterLastName + vocal + letterMothersLastName + letterNames;
        }
        else
        {
            rfcString = letterLastName + letterMothersLastName + letterNames + matcherNames.group(2);
        }

        if (rfcString.matches("B(?:(UE)[IY])|WE[IY]|C(?:A[CGK][AO]|O(?:GE|J[AEIO])|ULO)|FETO|GUEY|JOTO|K(?:A(?:[CG][AO]|KA)|O(?:GE|JO)|ULO)|LO([CK][AO])" +
                "|M(?:AM[EO]|E(?:A[RS]|ON)|ION|O(CO|KO)|UL[AO])|NAC[AO]|P(?:E(?:D[AO]|NE)|I(?:PI|TO)|O(?:PO)|UT[AO])|QULO|R(?:ATA|UIN)|SENO")){
            char[] ChangeChar = rfcString.toCharArray();
            ChangeChar[1] = 'X';
            rfcString = String.valueOf(ChangeChar);
        }

        RFC = NumberFormat(dNc, mNc, aNc);

        tv_RFC = findViewById(R.id.tv_RFC);
        tv_RFC.setText(rfcString+RFC);

    }

    private static String StringNormalizer(String sn)
    {
        sn = Normalizer.normalize(sn.replaceAll("[Ññ]","&"), Normalizer.Form.NFD);
        sn = sn.replaceAll("[^&a-zA-Z ]", "").toUpperCase().trim();
        return sn;
    }

    private static String NumberFormat(int dNc, int mNc, int aNc)
    {
        String day_Birth,month_Birth, year_Birth;
        if (dNc>0 && dNc<9)
        {
            day_Birth = "0"+dNc;
        }else{
            day_Birth = String.valueOf(dNc);
        }

        if (mNc>=0 && mNc<9){
            month_Birth = "0"+(mNc+1);
        }else {
            month_Birth = String.valueOf(mNc+1);
        }
        year_Birth = String.valueOf(aNc).substring(2);
        return year_Birth+month_Birth+day_Birth;
    }

    private void CalculateAge(int dayBd, int monthBd, int yearBd) {
        Calendar c = Calendar.getInstance();
        int ActDay = c.get(Calendar.DAY_OF_MONTH);
        int ActMonth = c.get(Calendar.MONTH);
        int ActYear = c.get(Calendar.YEAR);

        int age = ActYear - yearBd;
        if (monthBd > ActMonth) {
            age--;
        } else if (ActMonth == monthBd) {
            if (dayBd > ActDay) {
                age--;
            }
        }

        tv_Age = findViewById(R.id.tv_Age);
        tv_Age.setText(age+" ");
    }

    private void CalculateZodiacSign(int dayBd, int monthBd){

        String ZodiacSign="";
        ImageView imgZS = (ImageView) findViewById(R.id.imgZSC);

        if(monthBd == 0){
            if (dayBd < 20){
                ZodiacSign = getString(R.string.Capricorn);
                imgZS.setImageResource(R.drawable.capricorn);
            }else{
                ZodiacSign = getString(R.string.Aquarius);
                imgZS.setImageResource(R.drawable.aquarius);
            }
        }else if(monthBd == 1){
            if (dayBd < 19){
                ZodiacSign = getString(R.string.Aquarius);
                imgZS.setImageResource(R.drawable.aquarius);
            }else{
                ZodiacSign = getString(R.string.Pisces);
                imgZS.setImageResource(R.drawable.pisces);
            }
        }else if(monthBd == 2){
            if (dayBd < 20){
                ZodiacSign = getString(R.string.Pisces);
                imgZS.setImageResource(R.drawable.pisces);
            }else{
                ZodiacSign = getString(R.string.Aries);
                imgZS.setImageResource(R.drawable.aries);
            }
        }else if(monthBd == 3){
            if (dayBd < 20){
                ZodiacSign = getString(R.string.Aries);
                imgZS.setImageResource(R.drawable.aries);
            }else{
                ZodiacSign = getString(R.string.Taurus);
                imgZS.setImageResource(R.drawable.taurus);
            }
        }else if(monthBd == 4){
            if (dayBd < 21){
                ZodiacSign = getString(R.string.Taurus);
                imgZS.setImageResource(R.drawable.taurus);
            }else{
                ZodiacSign = getString(R.string.Gemini);
                imgZS.setImageResource(R.drawable.gemini);
            }
        }else if(monthBd == 5){
            if (dayBd < 21){
                ZodiacSign = getString(R.string.Gemini);
                imgZS.setImageResource(R.drawable.gemini);
            }else{
                ZodiacSign = getString(R.string.Cancer);
                imgZS.setImageResource(R.drawable.cancer);
            }
        }else if(monthBd == 6){
            if (dayBd < 23){

                imgZS.setImageResource(R.drawable.cancer);
            }else{
                ZodiacSign = getString(R.string.Leo);
                imgZS.setImageResource(R.drawable.leo);
            }
        }else if(monthBd == 7){
            if (dayBd < 23){
                ZodiacSign = getString(R.string.Leo);
                imgZS.setImageResource(R.drawable.leo);
            }else{
                ZodiacSign = getString(R.string.Virgo);
                imgZS.setImageResource(R.drawable.virgo);
            }
        }else if(monthBd == 8){
            if (dayBd < 23){
                ZodiacSign = getString(R.string.Virgo);
                imgZS.setImageResource(R.drawable.virgo);
            }else{
                ZodiacSign = getString(R.string.Libra);
                imgZS.setImageResource(R.drawable.libra);
            }
        }else if(monthBd == 9){
            if (dayBd < 23){
                ZodiacSign = getString(R.string.Libra);
                imgZS.setImageResource(R.drawable.libra);
            }else{
                ZodiacSign = getString(R.string.Scorpio);
                imgZS.setImageResource(R.drawable.scorpius);
            }
        }else if(monthBd == 10){
            if (dayBd < 22){
                ZodiacSign = getString(R.string.Scorpio);
                imgZS.setImageResource(R.drawable.scorpius);
            }else{
                ZodiacSign = getString(R.string.Sagittarius);
                imgZS.setImageResource(R.drawable.sagittarius);
            }
        }else if(monthBd == 11){
            if (dayBd < 21){
                ZodiacSign = getString(R.string.Sagittarius);
                imgZS.setImageResource(R.drawable.sagittarius);
            }else{
                ZodiacSign = getString(R.string.Capricorn);
                imgZS.setImageResource(R.drawable.capricorn);
            }
        }

        tv_ZodiacSign = findViewById(R.id.tv_ZodiacSign);
        tv_ZodiacSign.setText(ZodiacSign+" ");
    }
}