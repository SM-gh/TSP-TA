package com.example.rfccalculator;

import android.app.AlertDialog;
import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.app.DatePickerDialog;
import java.util.Calendar;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn_Birthdate, btn_Save;
    EditText et_Names, et_LastName, et_SecondLastName;
    Bundle BundleMain = new Bundle();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_main);

        btn_Birthdate = findViewById(R.id.btn_Birthdate);
        btn_Save = findViewById(R.id.btn_Save);
        et_Names =  findViewById(R.id.et_Names);
        et_LastName =  findViewById(R.id.et_LastName);
        et_SecondLastName =  findViewById(R.id.et_SecondLastName);

        btn_Birthdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PasteDate();
            }
        });

        btn_Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ValidateFields();
            }
        });
    }

    private void ValidateFields(){

        String StringNames = et_Names.getText().toString().trim();
        String StringLastName = et_LastName.getText().toString().trim();
        String StringMothersLastName = et_SecondLastName.getText().toString().trim();

        BundleMain.putString("stringnames", StringNames);
        BundleMain.putString("stringlastname", StringLastName);
        BundleMain.putString("stringmotherslastname", StringMothersLastName);

        int dateValidate = BundleMain.getInt("DayBirthdate");

        if(StringNames.isEmpty()){
            et_Names.setError(getString(R.string.alert_EmptyField));
            et_Names.requestFocus();
        }
        else if(StringLastName.isEmpty()){
            et_LastName.setError(getString(R.string.alert_EmptyField));
            et_LastName.requestFocus();
        } else if(StringMothersLastName.isEmpty()){
            et_SecondLastName.setError(getString(R.string.alert_EmptyField));
            et_SecondLastName.requestFocus();
        }else if(dateValidate == 0){
            Toast.makeText(getApplicationContext(),getString(R.string.alert_EmptyDate), Toast.LENGTH_SHORT).show();
        }else{
            Intent i = new Intent(MainActivity.this, SecondActivity.class);
            i.putExtras(BundleMain);
            startActivity(i);
        }
    }

    private void  PasteDate(){
        Calendar c = Calendar.getInstance();
        int dPD = c.get(Calendar.DAY_OF_MONTH);
        final int mPD = c.get(Calendar.MONTH);
        int yPD = c.get(Calendar.YEAR);

        DatePickerDialog dpd = new DatePickerDialog(MainActivity.this, AlertDialog.THEME_HOLO_DARK ,new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                BundleMain.putInt("DayBirthdate",dayOfMonth);
                BundleMain.putInt("MonthBirthdate",month);
                BundleMain.putInt("YearBirthdate",year);
                btn_Birthdate.setText(dayOfMonth+"/"+(month+1)+"/"+year);
            }
        },dPD,mPD,yPD);
        dpd.getDatePicker().setMaxDate(c.getTimeInMillis());
        dpd.show();
    }
}